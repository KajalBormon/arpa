#include<bits/stdc++.h>
using namespace std;
int main()
{
    cout<<"\n\n------Additive Cipher----------\n\n";
    string str;

    string new_text="",cyper,plain;
    char ch;
    char m;
    int k;
    cout<<"Enter your Text: ";
    getline(cin,str);
    cout<<"Enter your Key : ";
    cin>>k;
    while(m!='n')
    {

        cout<<"Press 1 for Encrypt Data : "<<endl;
        cout<<"Press 2 for decrypt Data : "<<endl;;
        int d;
        cin>>d;


        switch(d)
        {
        case 1:
            for(int i=0;i<str.size();i++)
            {
                if(str[i]>='a' && str[i]<='z')
                {
                    new_text+=str[i];
                }
            }

            for(int i=0; i<new_text.size(); i++)
            {
                     ch= ((new_text[i]-'a'+k)%26)+'A';
                     cyper+=ch;

            }
            cout<<"Cipher Text: "<<cyper<<endl;
            break;


        case 2:
            for(int i=0; i< cyper.size(); i++)
            {
                    char ch= ((cyper[i]-'A'+(26-k))%26)+'a';
                    plain+=ch;

            }
            cout<<"Decrypt data :  "<<plain<<endl;
            break;
        default:
            cout<<" Invalid Input"<<endl;

        }
        cout<<"\n Do you want to run more y/n : "<<endl;
        cin>>m;

    }

    return 0;

}
