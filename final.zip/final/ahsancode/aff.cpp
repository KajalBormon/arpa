#include<bits/stdc++.h>
using namespace std;
int main()
{
    cout<<"\n\n------Affine Cipher----------\n\n";
    string str;
     string new_text="",cyper,plain;
    char ch;
    int key1,key2;
    cout<<"Enter your Text: ";
    getline(cin,str);
    cout<<"Enter your Key 1 : ";
    cin>>key1;
    cout<<"Enter your Key 2 : ";
    cin>>key2;

    while(ch!='n')
    {

        cout<<"Press 1 for Encrypt Data : "<<endl;
        cout<<"Press 2 for decrypt Data : "<<endl;;
        int d;
        cin>>d;

        switch(d)
        {
        case 1:
            for(int i=0;i<str.size();i++)
            {
                if(str[i]>='a' && str[i]<='z')
                {
                    new_text+=str[i];
                }
            }

            for(int i=0; i<new_text.size(); i++)
            {
                      ch= (((new_text[i]-'a')*key1)+key2) %26+'A';
                     cyper+=ch;

            }
            cout<<"Cipher Text: "<<cyper<<endl;
            break;

        case 2:
            int a=26,b,r,q,t1=0,t2=1,t;
            b=key1;
            int res=__gcd(a,b);
            if(res!=1)
            {
                cout<<"Input is Invalid"<<endl;
            }

            else
            {
                while(a!=1)
                {
                    q=a/b;
                    r=a%b;
                    t=t1-t2*q;
                    t1=t2;
                    t2=t;
                    a=b;
                    b=r;
                }
                if(t1<0)

                {
                    t1=26+t1;
                }

                for(int i=0; i<cyper.size(); i++)
                {
                        char ch= ((((cyper[i]-'A')+(26-key2))*t1)%26)+'a';
                        plain+=ch;
                }
                cout<<" Decrypt Data : "<<plain<<endl;
            }
            break;
        }
        cout<<"\n Do you want to run more y/n : ";
        cin>>ch;

    }

    return 0;

}
