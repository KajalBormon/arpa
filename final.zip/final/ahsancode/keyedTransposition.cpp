#include<bits/stdc++.h>
using namespace std;

int main(){

    int keySize, count=0;
    string plaintext, newPlaintext="",finalplaintext="", ciphertext="", tmpCipher="";
    char p[]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    char c[]={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
// input plaintext
    cout<<"Give a plaintext : ";
    getline(cin, plaintext);
//length of the plaintext
    int len = plaintext.length();
//input key size
    cout<<"Key size : ";
    cin>>keySize;

    int keyValues[keySize];
    //input key values
    cout<<"Enter the key values : ";
    for(int i=0; i<keySize; i++){
        cin>>keyValues[i];
    }

    //remove space in the plaintext

    for(int i=0; i<len; i++){
        if(plaintext[i] != ' '){
            newPlaintext += plaintext[i];
        }
    }
// length after removing space of plaintext
    int newLength = newPlaintext.length();


    // add bogus character
    finalplaintext += newPlaintext;
    int bogus = keySize-(newLength%keySize);
    for(int i=0; i<bogus; i++){
        finalplaintext += 'z';
    }
// length of plaintext after adding bogus characters
    int finalLength = finalplaintext.length();

    //encryption 

    for(int i=0; i<finalLength; i++){
        count++;
        //lowercase to uppercase conversion and create a block, block size is equal to keysize
        for (int j = 0; j < 26; ++j) {
            if (p[j] == finalplaintext[i]) {
                tmpCipher += c[j];
            }
        }
//block by block encryption
        if(count==keySize){
            for(int k=0; k<keySize; k++){
                ciphertext += tmpCipher[keyValues[k]-1];
            }
            
            tmpCipher="";
            count=0;
        }
    }

// print output as a ciphertext
cout<<ciphertext;

    return 0;
}