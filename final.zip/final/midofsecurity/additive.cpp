#include<iostream>
#include<algorithm>
using namespace std;
string additive_cipher_encrypt(const string& text, int k);
string additive_cipher_decrypt(const string& text, int k);
int main()
{
    string text;
    cout << "Enter the text: ";
    getline(cin, text);

    int k;
    cout << "Enter the key: ";
    cin >> k;

    string cipherText = additive_cipher_encrypt(text, k);
    cout << "The cipherText is: " << cipherText << "\n";

    string decipherText = additive_cipher_decrypt(cipherText, k);
    cout << "The decipherText is: " << decipherText << "\n";

    return 0;
}
string additive_cipher_encrypt(const string& text, int k)
{
    string result = "";

    for(char ch : text)
    {
        if(isalpha(ch))
        {
            char base = islower(ch) ? 'a' : 'A';
            result += ((ch - base + k) % 26 + base);
        }
        else if (ch == ' ')
        {
            result += ' ';
        }
    }

    return result;
}

string additive_cipher_decrypt(const string& text, int k)
{
    string result = "";

    for(char ch : text)
    {
        if(isalpha(ch))
        {
            char base = islower(ch) ? 'a' : 'A';
            result += ((ch - base - k + 26) % 26 + base);
        }
        else if (ch == ' ')
        {
            result += ' ';
        }
    }

    return result;
}
