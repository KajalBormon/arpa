#include<bits/stdc++.h>`

using namespace std;

int main()
{
    int sz;
    cout<<"Enter key size : ";
    cin>>sz; //5
    vector<int>ky;
    cout<<"Enter the key values : ";
    for(int i=0; i<sz; i++)
    {
        int x;
        cin>>x;
        ky.push_back(x-1); // 3 1 5 4 2
    }
    string s,enc="";
    cout<<"Enter the plain text : ";
    cin.ignore();
    getline(cin,s); //enemy attac kszzz
    int cnt=0,pos=0;
    string str="";
    for(int i=0; i<s.size(); i++)
    {
        if(s[i]>='a' && s[i]<='z') str+=s[i];
    }
    cnt=sz-str.size()%sz;
    if(cnt!=sz){
        while(cnt--)
        str+='z';
    }

    cnt=0;
    int j=0;
    string t="";
    for(int i=0; i<str.size(); i++)
    {
        if(i%sz==0 && i!=0) { j=i;}
        enc+=(str[j+ky[i%sz]]-32);
    }
    cout<<enc<<endl;
}
