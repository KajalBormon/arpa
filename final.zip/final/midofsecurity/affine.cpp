#include<iostream>
#include<algorithm>
using namespace std;

string encryption_affine(string plainText, int k1, int k2);
string decryption_affine(string cipherText, int k1, int k2);
int modInverse(int a, int m);
int gcdExtended(int a, int b, int &x, int &y);
int main()
{
    string plainText;
    cout << "Enter the plain text: ";
    getline(cin, plainText);

    int k1, k2;
    cout << "Enter the keys: ";
    cin >> k1 >> k2;

    int k1_inverse = modInverse(k1, 26);

    while(k1_inverse == -1)
    {
        cout << "There is no multiplicative inverse for " << k1 << ".\nEnter valid keys: ";
        cin >> k1 >> k2;
        k1_inverse = modInverse(k1, 26);
    }

    string cipherText = encryption_affine(plainText, k1, k2);
    cout << "The cipherText is: " << cipherText << "\n";

    string decipherText = decryption_affine(cipherText, k1, k2);
    cout << "The decipherText is: " << decipherText << "\n";

    return 0;
}

string encryption_affine(string plainText, int k1, int k2)
{
    string cipherText = "";
    for(int i=0; i<plainText.size(); i++)
    {
        if (plainText[i] != ' ')
            cipherText += (((plainText[i] - 'a') * k1) + k2) % 26 + 'A';
        else
            cipherText += ' ';
    }

    return cipherText;
}

string decryption_affine(string cipherText, int k1, int k2)
{
    int k1_inverse = modInverse(k1, 26);

    string decipherText = "";
    for(int i=0; i<cipherText.size(); i++)
    {
        if (cipherText[i] != ' ')
            decipherText += (((cipherText[i] + 'A' - k2) * k1_inverse) % 26) + 'a';
        else
            decipherText += ' ';
    }
    return decipherText;
}

int modInverse(int a, int m)
{
    int x, y;
    int gcd = __gcd(a, m);
    if (gcd != 1)
    {
        return -1;
    }
    else
    {
        gcdExtended(a, m, x, y);
        return (x % m + m) % m;
    }
}

int gcdExtended(int a, int b, int &x, int &y)
{
    if (a == 0)
    {
        x = 0;
        y = 1;
        return b;
    }
    int x1, y1;
    int gcd = gcdExtended(b % a, a, x1, y1);
    x = y1 -(b / a) * x1;
    y = x1;
    return gcd;
}
