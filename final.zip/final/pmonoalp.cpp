#include<bits/stdc++.h>
using namespace std;

int main()
{
    char p[]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    char c[]={'N','O','A','T','R','B','E','C','F','U','X','D','Q','G','Y','L','K','H','V','I','J','M','P','Z','S','W'};
    string plaintext, newPlaintext, ciphertext="", cipherText="";

    cout<<"Enter the plaintext : ";
    getline(cin, plaintext);

    int len = plaintext.length();

    for(int i=0;i<len; i++){
        int j = plaintext[i]-'a';
        if(plaintext[i]!=' '){
            ciphertext +=c[j];
            cipherText +=c[j];
        }
        else{
            cipherText +=' ';
        }
    }

    cout<<ciphertext<<endl;


int index;
    for(int i=0;i<len; i++){
        for(int j=0;j<26;j++){
            if(cipherText[i]==c[j]){
                index=j;
                break;
            }
        }
        if(cipherText[i]!=' '){
            newPlaintext+=p[index];
        }
        else{
            newPlaintext+=' ';
        }
    }

    cout<<newPlaintext;



    return 0;
}